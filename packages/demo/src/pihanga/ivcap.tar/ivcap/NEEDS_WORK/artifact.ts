// import { v4 as uuidv4 } from "uuid"
// import {
//   PiRegister,
//   ReduxState,
//   ReduxAction,
//   createOnAction,
//   DispatchF,
// } from "@pihanga/core"
// import { URN, getAccessToken } from "."
// import {
//   ACTION_TYPES,
//   BaseEvent,
//   createListAction,
//   createReadAction,
//   ListEvent,
//   LoadListEvent,
//   LoadRecordEvent,
// } from "./actions"
// import {
//   getNextPage,
//   createListUrlBuilder,
//   restErrorHandling,
//   dispatchEvent,
// } from "./common"

// // LIST

// type ArtifactListEvent = ListEvent & {
//   artifacts: ArtifactListItem[]
// }

// export type ArtifactListItem = {
//   id: string
//   name: string
//   status: string
//   accountID: string
//   //template?: Template<T>
// }

// export type LoadArtifactListEvent = LoadListEvent<ArtifactListEvent>

// export function dispatchIvcapGetArtifactList(
//   ev: LoadArtifactListEvent,
//   dispatch: DispatchF,
// ): void {
//   const a = createListAction(ACTION_TYPES.LOAD_ARTIFACT_LIST, ev)
//   dispatch(a)
// }

// type RequestEvent = { reqID?: string }

// type ReduceF<S extends ReduxState, E extends RequestEvent> = (
//   state: S,
//   event: E,
//   dispatch: DispatchF,
// ) => S
// type ThenF<S extends ReduxState, E extends RequestEvent> = (
//   r: ReduceF<S, E>,
// ) => PromiseT<S, E>
// type PromiseT<S extends ReduxState, E extends { reqID?: string }> = {
//   then: ThenF<S, E>
// }
// type PropT<P> = Omit<P, keyof BaseEvent>


// // const myPromise: Promise<string> = new Promise((resolve, reject) => {
// //   // This Promise resolves to a string
// // })
// // const x = myPromise.catch(() => { }).then(() => { })

// // console.log(myPromise, x)

// export function getArtifactList<
//   S extends ReduxState,
//   P = LoadArtifactListEvent,
// >(
//   apiURL: URL,
//   register: PiRegister,
// ): (props: PropT<P>) => PromiseT<S, ArtifactListEvent> {
//   return (props: PropT<P>) => {
//     const reqID = uuidv4()
//     dispatchIvcapGetArtifactList(
//       { apiURL, reqID, ...props },
//       register.reducer.dispatchFromReducer,
//     )
//     return getPromise<S, ArtifactListEvent>(register, reqID)
//   }
// }

// function getPromise<S extends ReduxState, E extends { reqID?: string }>(
//   register: PiRegister,
//   reqID: string,
// ): PromiseT<S, E> {
//   let thenF: ReduceF<S, E> | undefined
//   register.reducer.registerOneShot<S, ReduxAction & E>(
//     ACTION_TYPES.ARTIFACT_LIST,
//     (s, a, d) => {
//       if (thenF && a.reqID === reqID) {
//         return [thenF(s, a, d), true]
//       }
//       return [s, false]
//     },
//   )
//   const res: PromiseT<S, E> = {
//     then: (f) => {
//       thenF = f
//       return res
//     },
//   }
//   return res
// }

// const c = getArtifactList<ReduxState>(new URL("foo"), {} as any as PiRegister)
// const p = c({})
// p.then((s) => s).then((s) => s)

// export const onArtifactList = createOnAction<ArtifactListEvent>(
//   ACTION_TYPES.ARTIFACT_LIST,
// )

// // RECORD

// type ArtifactRecordEvent = {
//   artifact: ArtifactRecord
// }

// export type ArtifactRecord = {
//   id: string
//   name: string
//   status: string
//   mimeType: string
//   size: number
//   dataURL: string
//   accountID: string
// }

// export type LoadArtifactRecordEvent<T = {}> = LoadRecordEvent<T>

// export function dispatchIvcapGetArtifactRecord<T = {}>(
//   ev: LoadArtifactRecordEvent<T>,
//   dispatch: DispatchF,
// ): void {
//   const a = createReadAction(ACTION_TYPES.LOAD_ARTIFACT_RECORD, ev)
//   dispatch(a)
// }

// export const onArtifactRecord = createOnAction<ArtifactRecordEvent>(
//   ACTION_TYPES.ARTIFACT_DETAIL,
// )

// // DATA DOWNLOAD

// export type ArtifactDataEvent = {
//   artifactID: string
//   data: Blob | any
//   size: number
//   mimeType: string
// }

// export type LoadArtifactDataEvent<T = {}> = BaseEvent<T> & {
//   id: string
//   dataURL: string
// }

// export function dispatchIvcapGetArtifactData<T = {}>(
//   ev: LoadArtifactDataEvent<T>,
//   dispatch: DispatchF,
// ): void {
//   const a = createReadAction(ACTION_TYPES.LOAD_ARTIFACT_DATA, ev)
//   dispatch(a)
// }

// export const onArtifactData = createOnAction<ArtifactDataEvent>(
//   ACTION_TYPES.ARTIFACT_DATA,
// )

// // DATA UPLOAD

// export type UploadArtifactDataEvent<T = {}> = BaseEvent<T> & {
//   file: File
//   name?: string // if not set, use file.name
//   chunkSize?: number
//   refID?: string
// }

// export type ArtifactUploadedEvent = {
//   name: string
//   artifactURN: URN
//   size: number
//   contentType: string
//   refID?: string
// }

// export function dispatchIvcapUploadArtifactData<T = {}>(
//   ev: UploadArtifactDataEvent<T>,
//   dispatch: DispatchF,
// ): void {
//   const a = { type: ACTION_TYPES.UPLOAD_ARTIFACT_DATA, ...ev }
//   dispatch(a)
// }

// export const onArtifactUploaded = createOnAction<ArtifactUploadedEvent>(
//   ACTION_TYPES.UPLOADED_ARTIFACT_RECORD,
// )

// export type ArtifactPartialUploadEvent<T = {}> = BaseEvent<T> & {
//   name: string
//   artifactURN: URN
//   refID?: string
//   content: ArrayBuffer
//   contentType: string
//   offset: number
//   size: number
//   chunkSize: number
//   timeStamp: number
// }

// export type ArtifactUploadProgressEvent = {
//   name: string
//   artifactURN: URN
//   refID?: string
//   progress: number // percent
//   uploadRate: number // byes/sec
// }

// export const onArtifactUploadProgress =
//   createOnAction<ArtifactUploadProgressEvent>(
//     ACTION_TYPES.UPLOAD_ARTIFACT_PROGRESS,
//   )

// //====== API HANDLER

// export function init(register: PiRegister): void {
//   register.GET<ReduxState, ReduxAction & LoadArtifactListEvent, any>({
//     name: "loadArtifactList",
//     origin: ({ apiURL }, _) => apiURL,
//     url: createListUrlBuilder("artifacts"),
//     trigger: ACTION_TYPES.LOAD_ARTIFACT_LIST,
//     //request: (a, _) => a as any,
//     headers: () => ({ Authorization: `Bearer ${getAccessToken()}` }),
//     reply: (state, content: any, dispatch, { request }) => {
//       const ev: ArtifactListEvent = {
//         nextPage: getNextPage(content.links),
//         artifacts: (content.artifacts || []).map(toArtifactListItem),
//       }
//       dispatchEvent(ev, ACTION_TYPES.ARTIFACT_LIST, dispatch, request.mapper)
//       return state
//     },
//     error: restErrorHandling("ivcap-api:loadArtifactList"),
//   })

//   register.GET<ReduxState, ReduxAction & LoadArtifactRecordEvent, any>({
//     name: "getArtifactDetail",
//     origin: ({ apiURL }, _) => apiURL,
//     url: "/1/artifacts/:id",
//     trigger: ACTION_TYPES.LOAD_ARTIFACT_RECORD,
//     request: ({ id }, _) => ({ id }),
//     headers: () => ({ Authorization: `Bearer ${getAccessToken()}` }),
//     reply: (state, content: any, dispatch, { request }) => {
//       const ev: ArtifactRecordEvent = {
//         artifact: toArtifactRecord(content),
//       }
//       dispatchEvent(
//         ev,
//         ACTION_TYPES.ARTIFACT_DETAIL,
//         dispatch,
//         request.template,
//       )
//       return state
//     },
//     error: restErrorHandling("ivcap-api:getArtifactDetail"),
//   })

//   register.GET<ReduxState, ReduxAction & LoadArtifactDataEvent, any>({
//     name: "getArtifactData",
//     origin: ({ dataURL }, _) => new URL(dataURL).origin,
//     url: "/1/artifacts/:id/blob",
//     trigger: ACTION_TYPES.LOAD_ARTIFACT_DATA,
//     // request: ({ dataURL }) => ({ path: new URL(dataURL).pathname }),
//     request: (a, _) => {
//       const id = a.id.split(":")[3]
//       return { id }
//     },
//     headers: () => ({ Authorization: `Bearer ${getAccessToken()}` }),
//     reply: (state, content: any, dispatch, { request, contentType }) => {
//       const { id, template } = request
//       const blob = content as Blob
//       const evb: ArtifactDataEvent = {
//         artifactID: id,
//         data: blob,
//         mimeType: contentType,
//         size: blob.size,
//       }
//       dispatchEvent(evb, ACTION_TYPES.ARTIFACT_DATA, dispatch, template)
//       return state
//     },
//     error: restErrorHandling("ivcap-api:getArtifactData"),
//   })

//   register.POST<ReduxState, ReduxAction & UploadArtifactDataEvent, any>({
//     name: "createArtifact",
//     origin: ({ apiURL }, _) => apiURL,
//     url: "/1/artifacts",
//     trigger: ACTION_TYPES.UPLOAD_ARTIFACT_DATA,
//     request: ({ file }) => {
//       return {
//         body: "",
//         contentType: file.type,
//       }
//     },
//     headers: ({ name, file }) => ({
//       Authorization: `Bearer ${getAccessToken()}`,
//       "X-Content-Length": `${file.size}`,
//       "X-Content-Type": `${file.type}`,
//       "Upload-Length": `${file.size}`,
//       "X-Name": btoa(name || file.name),
//     }),
//     reply: (state, reply: any, dispatch, { request }) => {
//       const reader = new FileReader()
//       reader.readAsArrayBuffer(request.file)
//       reader.onload = (): void => {
//         const content = reader.result
//         const size = request.file.size
//         let chunkSize: number
//         if (request.chunkSize) {
//           chunkSize = request.chunkSize
//         } else {
//           chunkSize = Math.min(size / 5, 4000000)
//           chunkSize = Math.trunc(Math.max(chunkSize, 2000000))
//         }

//         dispatch<ReduxAction & ArtifactPartialUploadEvent>({
//           name: request.name || request.file.name,
//           type: ACTION_TYPES.UPLOAD_ARTIFACT_PARTIAL,
//           apiURL: request.apiURL,
//           artifactURN: reply["id"],
//           content: content as ArrayBuffer,
//           contentType: request.file.type,
//           refID: request.refID,
//           offset: 0,
//           size,
//           chunkSize,
//           timeStamp: Date.now(),
//           template: request.template,
//         })
//       }
//       reader.onerror = (): void => {
//         restErrorHandling("ivcap-api:loadFile")
//       }
//       return state
//     },
//     error: restErrorHandling("ivcap-api:createArtifact"),
//   })

//   register.PATCH<ReduxState, ReduxAction & ArtifactPartialUploadEvent, any>({
//     name: "uploadArtifactPartial",
//     origin: ({ apiURL }, _) => apiURL,
//     url: "/1/artifacts/:id/blob",
//     trigger: ACTION_TYPES.UPLOAD_ARTIFACT_PARTIAL,
//     request: ({ artifactURN, content, offset, chunkSize, contentType }) => {
//       const body = content.slice(offset, offset + chunkSize)
//       return {
//         bindings: { id: artifactURN },
//         body,
//         contentType,
//       }
//     },
//     headers: ({ offset, chunkSize, size }) => {
//       const l = Math.min(chunkSize, size - offset)
//       return {
//         Authorization: `Bearer ${getAccessToken()}`,
//         "Content-Type": "application/offset+octet-stream",
//         "Content-Length": `${l}`,
//         "Upload-Length": `${size}`,
//         "Upload-Offset": `${offset}`,
//         "Tus-Resumable": "1.0.0",
//       }
//     },
//     reply: (state, _, dispatch, { request }) => {
//       const offset = Math.min(request.offset + request.chunkSize, request.size)
//       if (offset >= request.size) {
//         // we are done
//         const evd: ArtifactUploadedEvent = {
//           name: request.name,
//           artifactURN: request.artifactURN,
//           size: request.size,
//           contentType: request.contentType,
//           refID: request.refID,
//         }
//         dispatchEvent(
//           evd,
//           ACTION_TYPES.UPLOADED_ARTIFACT_RECORD,
//           dispatch,
//           request.template,
//         )
//       } else {
//         const now = Date.now()
//         dispatch<ReduxAction & ArtifactPartialUploadEvent>({
//           ...request,
//           offset,
//           timeStamp: now,
//         })
//         const uploadRate =
//           (1000 * (offset - request.offset)) / (now - request.timeStamp)
//         const progress = (1.0 * offset) / request.size
//         dispatch<ReduxAction & ArtifactUploadProgressEvent>({
//           type: ACTION_TYPES.UPLOAD_ARTIFACT_PROGRESS,
//           name: request.name,
//           artifactURN: request.artifactURN,
//           refID: request.refID,
//           progress,
//           uploadRate,
//         })
//       }
//       return state
//     },
//     error: restErrorHandling("ivcap-api:uploadArtifactPartial"),
//   })
// }

// function toArtifactListItem(els: any): ArtifactListItem {
//   // {
//   //   id: 'urn:ivcap:artifact:cbcc1748-1a45-4369-85ee-e631b99676c4',
//   //   name: 'tmppsmdglsm-1154x866.pseudo.png',
//   //   status: 'ready'
//   // }
//   return {
//     id: els.id,
//     name: els.name,
//     status: els.status,
//     accountID: els.account_id,
//   }
// }

// function toArtifactRecord(els: any): ArtifactRecord {
//   // id: 'urn:ivcap:artifact:76fc1192-0eae-469a-b3a5-bda29f4924ce',
//   // name: 'tmp4kjnvxl9-1154x866.pseudo.png',
//   // data: {
//   //   self: 'https://develop.ivcap.net/1/artifacts/76fc1192-0eae-469a-b3a5-bda29f4924ce/blob'
//   // },
//   // status: 'ready',
//   // 'mime-type': 'image/jpeg',
//   // size: 18317,
//   // account: {
//   //   id: 'urn:ivcap:account:4c65b865-df6a-4977-982a-f96b19c1fda0'
//   // }
//   return {
//     id: els.id,
//     name: els.name,
//     status: els.status,
//     mimeType: els["mime-type"],
//     size: els.size,
//     dataURL: els.data?.self,
//     accountID: els.account?.id,
//   }
// }
