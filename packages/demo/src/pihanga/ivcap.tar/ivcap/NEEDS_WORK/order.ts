import {
  PiRegister,
  dispatchFromReducer,
  ReduxState,
  ReduxAction,
  createOnAction,
} from "@pihanga/core";
import { registerGET, registerPOST } from "@pihanga/rest-client";
import { getAccessToken } from ".";
import {
  ACTION_TYPES,
  BaseEvent,
  createListAction,
  createReadAction,
  ListEvent,
  LoadListEvent,
  LoadRecordEvent,
} from "./actions";
import { restErrorHandling, createListUrlBuilder, getNextPage, dispatchEvent } from "./common";

// LIST

type OrderListEvent = ListEvent & {
  orders: OrderListItem[];
};

export type OrderListItem = {
  id: string;
  name: string;
  status: string;
  orderedAt?: Date;
  startedAt?: Date;
  finishedAt?: Date;
  serviceID: string;
  accountID: string;
};

export type LoadOrderListEvent<T = {}> = LoadListEvent<T>;

export function dispatchIvcapGetOrderList<T = {}>(ev: LoadOrderListEvent<T>): void {
  const a = createListAction(ACTION_TYPES.LOAD_ORDER_LIST, ev);
  dispatchFromReducer(a);
}

export const onOrderList = createOnAction<OrderListEvent>(
  ACTION_TYPES.ORDER_LIST
);

// READ

type OrderRecordEvent = {
  order: OrderRecord;
};

export type OrderRecord = {
  id: string;
  name: string;
  status: string;
  orderedAt: Date;
  startedAt?: Date;
  finishedAt?: Date;
  parameters: OrderParameter[];
  products: OrderProduct[];
  serviceID: string;
  accountID: string;
};

export type OrderParameter = {
  name: string;
  value: string | number;
};

export type OrderProduct = {
  id: string;
  name: string;
  status: string;
  mimeType?: string;
  size?: number;
  dataURL?: string;
};

export type LoadOrderRecordEvent<T = {}> = LoadRecordEvent<T>;

export function dispatchIvcapGetOrderRecord<T = {}>(ev: LoadOrderRecordEvent<T>): void {
  const a = createReadAction(ACTION_TYPES.LOAD_ORDER_RECORD, ev);
  dispatchFromReducer(a);
}

export const onOrderRecord = createOnAction<OrderRecordEvent>(
  ACTION_TYPES.ORDER_DETAIL
);

// CREATE

export type OrderReceiptEvent = {
  refID: string; // internal id to relate request to reply
  order: OrderRecord;
};

type OrderCreateEvent<T = {}> = BaseEvent<T> & {
  id: string; // for internal reference
  serviceID: string;
  parameters: OrderParameter[];
};

export function dispatchIvcapCreateOrder<T = {}>(ev: OrderCreateEvent<T>): void {
  dispatchFromReducer({
    type: ACTION_TYPES.CREATE_ORDER,
    ...ev,
  });
}

export const onOrderReceipt = createOnAction<OrderReceiptEvent>(
  ACTION_TYPES.ORDER_RECEIPT
);

//====== API HANDLER

export function init(register: PiRegister): void {
  registerGET<ReduxState, ReduxAction & LoadOrderListEvent, any>(register)({
    name: "loadOrderList",
    origin: ({ apiURL }, _) => apiURL,
    url: createListUrlBuilder("orders"),
    trigger: ACTION_TYPES.LOAD_ORDER_LIST,
    request: (a, _) => a as any,
    headers: () => ({ Authorization: `Bearer ${getAccessToken()}` }),
    reply: (state, content: any, { template }) => {
      const ev: OrderListEvent = {
        nextPage: getNextPage(content.links),
        orders: (content.orders || []).map(toOrderListItem),
      };
      dispatchEvent(ev, ACTION_TYPES.ORDER_LIST, template)
      return state;
    },
    error: restErrorHandling("ivcap-api:loadOrderList"),
  });

  registerGET<ReduxState, ReduxAction & LoadOrderRecordEvent, any>(register)({
    name: "getOrderDetail",
    origin: ({ apiURL }, _) => apiURL,
    url: "/1/orders/:id",
    trigger: ACTION_TYPES.LOAD_ORDER_RECORD,
    request: ({ id }, _) => ({ id }),
    headers: () => ({ Authorization: `Bearer ${getAccessToken()}` }),
    reply: (state, content: any, { template }) => {
      const ev: OrderRecordEvent = {
        order: toOrderRecord(content),
      };
      dispatchEvent(ev, ACTION_TYPES.ORDER_DETAIL, template)
      return state;
    },
    error: restErrorHandling("ivcap-api:getOrderDetail"),
  });

  registerPOST<ReduxState, ReduxAction & OrderCreateEvent, any>(register)({
    name: "createOrder",
    origin: ({ apiURL }, _) => apiURL,
    url: "/1/orders",
    trigger: ACTION_TYPES.CREATE_ORDER,
    request: ({ id, serviceID, parameters }) => {
      return {
        body: { name: id, 'service-id': serviceID, parameters },
        contentType: "application/json",
      };
    },
    headers: () => ({ Authorization: `Bearer ${getAccessToken()}` }),
    reply: (state, reply: any, req) => {
      const order = toOrderRecord(reply)
      const ev: OrderReceiptEvent = {
        refID: req.id,
        order,
      };
      dispatchEvent(ev, ACTION_TYPES.ORDER_RECEIPT, req.template)
      return state;
    },
    error: restErrorHandling("ivcap-api:addMetadata"),
  });
}

function toOrderListItem(els: any): OrderListItem {
  // {
  //   "id": "urn:ivcap:order:f44d5dbd-77cd-448f-a270-99a7b24a36c6",
  //   "name": "Order f44d5dbd-77cd-448f-a270-99a7b24a36c6",
  //   "status": "Succeeded",
  //   "ordered_at": "2023-03-26T06:49:10Z",
  //   "started_at": "2023-03-26T06:53:16Z",
  //   "finished_at": "2023-03-26T06:56:15Z",
  //   "service_id": "urn:ivcap:service:8773f79e-d46c-559a-a63c-54c4e2a9d9a1",
  //   "account_id": "urn:ivcap:account:4c65b865-df6a-4977-982a-f96b19c1fda0",
  //   "links": {
  //     "self": "https://develop.ivcap.net/1/orders/f44d5dbd-77cd-448f-a270-99a7b24a36c6"
  //   }
  // }
  return {
    id: els.id,
    name: els.name,
    status: els.status,
    orderedAt: toDate('ordered-at', els),
    startedAt: toDate('started-at', els),
    finishedAt: toDate('finished-at', els),
    serviceID: els.service_id,
    accountID: els.account_id,
  };
}

function toOrderRecord(els: any): OrderRecord {
  // {
  //   id: 'urn:ivcap:order:cee25b3c-9dc2-4cf1-a854-8b5351590f93',
  //   name: 'Order cee25b3c-9dc2-4cf1-a854-8b5351590f93',
  //   status: 'Succeeded',
  //   ordered_at: '2023-03-26T06:49:09Z',
  //   started_at: '2023-03-26T06:53:06Z',
  //   finished_at: '2023-03-26T06:56:18Z',
  //   parameters: [
  //     {
  //       name: 'model',
  //       value: 'http://artifact.local/urn:ivcap:artifact:240c4714-8aa3-43b6-bded-6c7a08595e81'
  //     },
  //     ...
  //   ],
  //   products: [
  //     {
  //       id: 'urn:ivcap:artifact:24dc7977-5503-4779-9d26-3f869599641f',
  //       name: 'tmp_mj_r70d-1154x866.pseudo.png',
  //       status: 'Ready',
  //       'mime-type': 'image/jpeg',
  //       size: 17897,
  //       links: {
  //         self: 'https://develop.ivcap.net/1/artifacts/24dc7977-5503-4779-9d26-3f869599641f',
  //         data: 'https://develop.ivcap.net/1/artifacts/24dc7977-5503-4779-9d26-3f869599641f/blob'
  //       }
  //     }
  //   ],
  //   service: {
  //     id: 'urn:ivcap:service:8773f79e-d46c-559a-a63c-54c4e2a9d9a1',
  //     links: {
  //       self: 'https://develop.ivcap.net/1/services/8773f79e-d46c-559a-a63c-54c4e2a9d9a1'
  //     }
  //   },
  //   account: {
  //     id: 'urn:ivcap:account:4c65b865-df6a-4977-982a-f96b19c1fda0'
  //   },
  //   links: {
  //     self: 'https://develop.ivcap.net/1/orders/cee25b3c-9dc2-4cf1-a854-8b5351590f93'
  //   }
  // },

  const parameters = (els.parameters || []).map((p: any) => {
    return {
      name: p.name,
      value: p.value,
    };
  });

  const products = (els.products || []).map((p: any) => {
    return {
      id: p.id,
      name: p.name,
      status: p.status,
      mimeType: p["mime-type"],
      size: p.number,
      dataURL: p.links?.data,
    };
  });

  return {
    id: els.id,
    name: els.name,
    status: els.status,
    orderedAt: toDate('ordered-at', els)!,
    startedAt: toDate('started-at', els),
    finishedAt: toDate('finished-at', els),
    parameters,
    products,
    serviceID: els.service?.id,
    accountID: els.account?.id,
  };
}

function toDate(name: string, els: any): Date | undefined {
  const v = els[name]
  return v ? new Date(v) : undefined
}
