import logo from "./logo.svg"
import { Counter } from "./UNUSED/features/counter/Counter"
import "./App.css"

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <Counter />

      </header>
    </div>
  )
}

export default App
