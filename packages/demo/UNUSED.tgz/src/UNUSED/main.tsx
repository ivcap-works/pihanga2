import React from "react"
import { Provider } from "react-redux"
import type { Store } from "./pihanga/store"
import App from "./App"
import "./index.css"

export function RootComponent(store: Store) {
  return (
    <React.StrictMode>
      <Provider store={store}>
        <App />
      </Provider>
    </React.StrictMode>
  )
}
